
================================================================================
ORA SUITES WEBSITE ASSETS — VERSION 2 (UPDATED)
================================================================================

This package contains everything you need to build the Ora Suites website using Replit AI.

WHAT'S INCLUDED:
================================================================================

1. REPLIT_PROMPT_V2.txt
   - Complete, detailed prompt for Replit AI
   - Addresses all flaws found in competitor analysis (Derma Transform)
   - Focuses on emotional resonance, brand storytelling, and luxury UX
   - Includes SEO strategy, booking integration, and technical stack

2. IMAGES FOLDER (19 high-quality AI-generated images):

   ORIGINAL IMAGES (from first batch):
   - hero-image.png — Homepage hero section
   - service-aesthetics.png — Aesthetics service page
   - service-hair.png — Hair service page
   - service-nails.png — Nails service page
   - room-rental.png — Room rentals page
   - team-photo.png — About page / Team section
   - manchester-location.png — Location section
   - before-after-results.png — Social proof / Results gallery
   - reception-area.png — About page / Gallery

   NEW SERVICE CATEGORY IMAGES (tailored to Ora's aesthetic):
   - service-aesthetics-room.png — Luxury aesthetics treatment room
   - service-hair-station.png — Elegant hair styling station
   - service-nails-station.png — Luxury nail salon station
   - service-massage-wellness.png — Serene massage & wellness room
   - service-laser-treatment.png — Modern laser treatment room
   - consultation-room.png — Elegant consultation space
   - waiting-area-lobby.png — Luxury waiting area / lobby
   - product-display.png — Skincare products display
   - manicure-treatment.png — Close-up of manicure treatment
   - facial-treatment.png — Close-up of facial treatment

================================================================================
HOW TO USE WITH REPLIT AI:
================================================================================

STEP 1: Upload Images
- Go to Replit and create a new project
- Upload all images from the "images" folder to your project's assets directory

STEP 2: Copy the Prompt
- Open REPLIT_PROMPT_V2.txt
- Copy the entire prompt

STEP 3: Paste into Replit AI
- Open Replit AI chat
- Paste the prompt
- Replit AI will begin building the website based on the specifications

STEP 4: Customize
- Replace placeholder text with real content (founder story, team bios, etc.)
- Add real testimonials
- Integrate GoHighLevel booking forms
- Connect domain (orasuites.co.uk)

STEP 5: Launch
- Test on mobile and desktop
- Run SEO audit
- Set up Google My Business
- Go live!

================================================================================
KEY IMPROVEMENTS OVER COMPETITOR (DERMA TRANSFORM):
================================================================================

✅ EMOTIONAL BRAND STORYTELLING — Not transactional, transformational
✅ REFINED VISUAL AESTHETIC — Warm neutrals, luxury photography, cohesive palette
✅ CLEAR USER JOURNEY — Awareness → Education → Booking
✅ TRUST-BUILDING ELEMENTS — Testimonials, before/afters, social proof
✅ STRONG BRAND VOICE — Warm, intentional, confident
✅ MOBILE-FIRST DESIGN — Clean, thumb-friendly, fast
✅ SEO OPTIMIZED — Local SEO, schema markup, content strategy
✅ CONVERSION-FOCUSED — Clear CTAs, easy booking, trust signals

================================================================================
BRAND POSITIONING REMINDER:
================================================================================

Ora is NOT a clinic. It's a sanctuary.
- Positioning: "Where beauty meets intention. Where care becomes ritual."
- Target: Women seeking transformation, not just treatment
- Aesthetic: Refined luxury through simplicity, warmth, and emotional depth
- Voice: Warm, grounded, intentional

================================================================================
NEXT STEPS AFTER WEBSITE LAUNCH:
================================================================================

1. Set up Google My Business listing
2. Create Instagram content calendar
3. Launch email marketing (newsletter signup on site)
4. Run local SEO campaign (Manchester directories, backlinks)
5. Collect testimonials and before/after photos
6. Launch referral program
7. Host opening event / soft launch

================================================================================
SUPPORT:
================================================================================

If you need further customization or have questions, refer back to the original conversation with the AI assistant.

Good luck with the launch! 🌟

================================================================================
