
ORA SUITES WEBSITE ASSETS
=========================

This folder contains all assets needed to build the Ora Suites website.

CONTENTS:
---------
1. REPLIT_PROMPT.txt - Comprehensive development prompt for Replit AI
2. /images/ - All website images organized by purpose

HOW TO USE:
-----------
1. Upload this entire folder to your Replit project
2. Copy the contents of REPLIT_PROMPT.txt
3. Paste into Replit AI chat
4. Reference images from the /images/ folder in your code

IMAGE REFERENCE:
----------------
- hero-image.png: Homepage hero section
- service-aesthetics.png: Aesthetics service showcase
- service-nails.png: Nail services showcase
- service-hair.png: Hair services showcase
- room-rental.png: Professional room rental showcase
- team-photo.png: Team section
- manchester-location.png: Location/cityscape
- before-after-results.png: Treatment results
- reception-area.png: Reception/facility showcase

BRAND COLORS:
-------------
- MILK: #F0EDEB
- SAND: #F0EDEB
- BONE: #EEE7D7
- SMOKE: #C0B7A8
- FOG: #8C8575
- GREIGE: #E1DFDB

DOMAIN: orasuites.com

For questions or support, refer to the comprehensive prompt document.
